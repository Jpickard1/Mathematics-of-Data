function [clusters] = myKMeans(D, k)
% MYKMEANS: This function implements the K-Means algorithm
%    
%   INPUTS:
%       k: number of clusters in the data
%       D: n x m data matrix where each row (n) is one sample containing
%       (m) features in the columns
%
%   OUTPUT:
%       cluters: a n x 1 vector where the ith entry indicates which cluster
%       the ith row of D is assigned to.
%
% Auth: ...
% Date: ...

    % TODO: fill in the kmeans algorithm.
    disp("TODO: Fill in myKMeans implementation.")

end
